package com.moviebooking.auth.model;

public enum ERole {
  ROLE_CUSTOMER,
  ROLE_ADMIN
}

