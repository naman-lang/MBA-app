package com.cognizant.moviebookingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviebookingappMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviebookingappMicroserviceApplication.class, args);
	}

}
