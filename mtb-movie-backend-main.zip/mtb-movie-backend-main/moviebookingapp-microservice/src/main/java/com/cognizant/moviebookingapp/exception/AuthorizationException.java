package com.cognizant.moviebookingapp.exception;

public class AuthorizationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7560582148585522728L;

	public AuthorizationException(String msg) {
		super(msg);
	}
}