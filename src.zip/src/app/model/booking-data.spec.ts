import { BookingData } from './booking-data';

describe('BookingData', () => {
  it('should create an instance', () => {
    expect(new BookingData()).toBeTruthy();
  });
});
