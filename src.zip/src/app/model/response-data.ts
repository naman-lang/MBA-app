export class ResponseData {
    id:string|any;
    username: string | any;
    email: string | any;
    password: string | any;
    securityQuestion: string | any;
    securityAnswer: string | any;
    roles:any[]|any;//fix me later
}
