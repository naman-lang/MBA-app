import { TicketData } from './ticket-data';

describe('TicketData', () => {
  it('should create an instance', () => {
    expect(new TicketData()).toBeTruthy();
  });
});
